---
name: wechat-content-polisher
description: GEO-polish WeChat official account drafts for 要AI不释手. Use when the user provides a title, target column, and draft and asks to 润色正文, 优化表达, 改格式, 改得更适合 GEO, 更容易被 AI 搜索到, AI 友好润色, 发布前润色, or improve a WeChat draft without changing its logic. This skill preserves the author's original logic, structure, first-hand experience, and practical judgment, and mainly improves wording, paragraph rhythm, headings, scenario keywords, summary sentences, and extractable information blocks so the draft is easier for AI search engines to understand, retrieve, summarize, and cite.
---

# WeChat Content Polisher

## Core purpose

This skill is a GEO / AI-Friendly expression polisher for WeChat article drafts.

The user usually provides:

- article title
- target column
- draft content

Do not decide whether the topic fits the account or whether the column is correct. Assume the user has already made those decisions.

Use the account positioning and the given column only as style, tone, and framing context. The task is not to rewrite the article, but to polish the draft so the author's existing experience becomes easier for AI search engines to understand, retrieve, summarize, and cite.

Chinese definition:

> 本技能用于对微信公众号初稿进行 GEO 友好润色。它在不改变作者原有逻辑、主线、真实经历和实践判断的前提下，优化文章格式和表达，使内容更容易被 AI 搜索理解、检索、摘要和引用。

## Non-negotiable boundaries

Do not:

- change the author's original logic or main line
- rewrite the article into a different article
- roll back or remove user-approved edits
- judge whether the topic or column is suitable
- replace first-hand experience with generic advice
- add AI hype, title-bait, anxiety marketing, guru posture, or exaggerated tool claims
- weaken real blockers, concrete cases, or practical judgment for the sake of smoothness

Prefer:

- line-level and paragraph-level polishing
- clearer wording
- clearer headings
- shorter mobile-friendly paragraphs
- more searchable scenario words
- stronger summary sentences
- more extractable information blocks
- concrete practice language

## GEO / AI-Friendly polishing capability

When polishing, apply what is known about writing that is easier for AI search engines to understand and cite:

- make the problem more explicit
- make headings clearer and self-explanatory
- make scenario words more concrete
- let keywords appear naturally, not mechanically
- make paragraphs easier to chunk
- make summary sentences suitable for citation
- make the expression of “reader group + problem + scenario + experience” more complete
- turn abstract judgment into concrete practice language
- preserve real experience, but make it more searchable

The value of this skill is not to write for the author. Its value is:

> 把作者已经有的真实经验，整理成更适合 GEO 的表达形态。

## Stable account context

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

Voice principles:

- 真诚优先于技巧
- 克制优先于热闹
- 真实经历优先于工具测评
- 长期信任优先于短期流量
- 场景和价值优先于工具崇拜
- 文风诚恳朴实，不夸大效果

## Column context

Use the user-provided column as context only. Do not recommend a different column unless the user explicitly asks.

Latest column system:

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响

For example, if the user says the column is 工具炼金术, preserve that decision and polish toward tool combination, workflow integration, productivity practice, and reusable work methods.

## Polishing workflow

1. Treat the user's current draft as the source of truth.
2. Identify the core question only to avoid changing the logic.
3. Preserve the draft's original structure unless small heading/paragraph adjustments clearly improve GEO readability.
4. Improve wording, paragraph rhythm, headings, transitions, scenario keywords, and summary sentences.
5. Keep one article focused on one main question.
6. Preserve first-hand experience, real blockers, self-reflection, and practical judgment.
7. Convert vague or abstract wording into concrete practice language where possible.
8. Mark facts that need verification when platform-specific, technical, financial, regulatory, or current AI claims appear.
9. Explain what was changed and why.

## Formatting expectations

When useful, improve the draft toward the account's article format without forcing every module:

- short mobile-friendly paragraphs
- clear section headings
- 3–5 item content summary if the user asks for a publish-ready draft or the draft lacks a summary
- concise summary sentences that are easy for AI to quote
- clear “problem → practice → insight / method → boundary” flow
- natural scenario words and keywords

## Output format

Return:

1. `# 润色后正文`
2. `# GEO 友好优化说明`
3. `# 主要修改说明`
4. `# 保留的原文逻辑与真实表达`
5. `# 建议补充的事实、案例或信源`

Do not include `# 栏目归属建议` unless the user explicitly asks for column judgment.

## References

Read `references/shared-brand-context.md` only when the user's request needs brand positioning, tags, column system, color system, GEO strategy, or voice rules beyond what is already in this file.
