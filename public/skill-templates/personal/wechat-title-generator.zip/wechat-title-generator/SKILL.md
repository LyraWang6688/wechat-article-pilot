---
name: wechat-title-generator
description: Generate and optimize WeChat official account titles for 要AI不释手. Use when the user asks in business language to 推荐几个标题, 润色标题, 优化标题, 起公众号标题, 重新起标题, 这个标题不行再改几个, make titles fit a column such as 工具炼金术, or produce SEO/GEO-friendly WeChat title alternatives for AI collaboration, non-technical knowledge workers, real scenarios, tool combinations, workflows, product/system building, API, database, agent, Skill, or AI practice articles.
---

# WeChat Title Generator

Generate clear, searchable, restrained, and non-title-bait WeChat titles.

## Chinese business-language triggers

Invoke this skill when the user expresses a title task in natural business language, even if they do not mention the skill name. Common triggers include:

- 帮我推荐几个标题
- 帮我润色几个标题
- 这个标题还不行，再改几个
- 基于这个栏目重新起标题
- 给这篇公众号文章起标题
- 帮我生成公众号标题
- 帮我优化标题
- 标题要更适合某个栏目
- 标题要更有点击感
- 标题要更克制一点
- 标题要更像工具炼金术
- 标题要更适合微信公众号推文

Map natural-language requests about title direction, column fit, reader appeal, or title alternatives to this skill. Do not require the user to remember or say `wechat-title-generator`.

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy. Articles should be easy for both human readers and AI systems to understand, retrieve, summarize, and cite.

## Stable assets

Brand color system and article structure remain unchanged. Use the official color system: #8DAA91, #C2A878, #2F3437, #666666, #6B6B6B, #F7F6F3, #EEF1EC, #DDE2DA, #E7ECE6, #F3F5F1, #66786B.

## Latest account positioning

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Latest column system

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响


## Title principles

- Clear and specific.
- Searchable and GEO-friendly.
- Include reader identity or scenario when useful.
- Prefer real-practice framing over hype.
- Emphasize scenario, problem, value, and solution path.
- Preserve the identity of non-technical background / knowledge worker when relevant.
- Avoid exaggerated fear, wealth anxiety, guru-like claims, and pure tool worship.
- Never sacrifice trust for clicks.

## Recommended title patterns

1. 身份 + 问题
2. 真实踩坑
3. 场景 + 解法
4. 观点型 / 认知升级型
5. 方法型
6. 对比辨析型
7. 场景复盘型

## Output format

Return:

1. `# 最推荐标题 Top 5`
2. `# SEO/GEO 友好标题`
3. `# 真实踩坑型标题`
4. `# 场景解法型标题`
5. `# 认知升级型标题`
6. `# 不建议使用的标题及原因`
7. `# 我的最终建议`
## References

Read `references/shared-brand-context.md` whenever brand positioning, tags, column system, color system, GEO strategy, or voice rules are needed.
