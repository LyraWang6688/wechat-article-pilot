---
name: wechat-fact-checker
description: Use this skill when the user asks to check a WeChat draft for factual accuracy, professional rigor, technical correctness, platform capability claims, data accuracy, concept accuracy, source readiness, misleading wording, overgeneralization, exaggerated AI capability, or safety/security boundaries. Also use it for requests phrased as 专业性检查, 事实性检查, 事实核查, 真实性校验, 技术准确性检查, 严谨性检查, 发布前事实检查, 有没有说错, 有没有夸大, 是否误导, 是否需要信源, 安全边界是否准确, or 帮我检查这篇文章的专业性/事实性. The skill reviews claims, explains what is inaccurate or risky, gives reasons, and suggests safer revised wording.
---

# WeChat Fact Checker

## Core purpose

This skill checks factual, technical, platform, data, AI product, labor-market, financial, regulatory, and professional claims in WeChat article drafts.

It is used after the user already has draft content and wants to know whether the professional or factual statements are accurate, sufficiently qualified, and source-ready.

The task is not to polish the article or rewrite the full draft. The task is to identify inaccurate, risky, overgeneralized, unsupported, misleading, or insufficiently qualified statements, explain why they are problematic, and provide safer revision suggestions.

Chinese definition:

> 本技能用于检查微信公众号草稿中涉及专业性、事实性、技术概念、平台能力、数据、AI 产品、金融、监管、劳动力市场等内容是否准确、严谨、需要限定或需要补充信源。它不负责全文润色，而是负责指出哪里可能不准确、为什么不准确，并给出更稳妥的修改建议。

## Trigger phrases

Use this skill when the user says or implies:

- 事实检查
- 事实核查
- 真实性校验
- 专业性检查
- 事实性检查
- 技术准确性检查
- 概念是否准确
- 数据是否准确
- 平台能力是否准确
- 这个说法严谨吗
- 有没有说错
- 有没有夸大
- 有没有误导
- 是否需要信源
- 发布前事实检查
- 安全边界是否准确
- 帮我检查这篇文章的专业性
- 帮我检查这篇文章的事实性
- 帮我看这篇文章有没有专业风险

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy. Articles should be easy for both human readers and AI systems to understand, retrieve, summarize, and cite.

For fact checking, this means the final article should contain claims that are accurate, properly qualified, and easy for AI systems to cite without spreading misinformation.

## Stable assets

Brand color system and article structure remain unchanged. Use the official color system: #8DAA91, #C2A878, #2F3437, #666666, #6B6B6B, #F7F6F3, #EEF1EC, #DDE2DA, #E7ECE6, #F3F5F1, #66786B.

## Latest account positioning

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Latest column system

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响

## Rules

- Separate conceptual accuracy from current factual claims.
- Distinguish fact, interpretation, assumption, personal experience, and opinion.
- Mark claims requiring web verification or official documentation.
- For computer science concepts, AI products, APIs, databases, cloud services, deployment, security, platform capabilities, data, finance, economics, regulation, labor-market, or current AI information, require authoritative sources when the claim is not self-evident.
- Flag overgeneralization, exaggerated AI capability, misleading wording, and unqualified safety/security claims.
- For each problematic claim, explain why it is inaccurate, risky, or insufficiently qualified.
- Suggest safer rewrites rather than simply saying a statement is wrong.
- For finance/investment content, avoid recommendations, market predictions, and wealth anxiety.
- When current facts may have changed, verify with web search or clearly mark that verification is needed.
- Do not invent citations, statistics, product capabilities, or technical details.

## Review method

For each draft:

1. Identify claims that are factual, technical, data-based, platform-specific, financial, regulatory, security-related, or current.
2. Classify each claim as:
   - accurate enough
   - needs qualification
   - needs source verification
   - potentially misleading
   - likely inaccurate
3. Explain the reason for the judgment.
4. Provide a safer replacement sentence or paragraph.
5. List the authoritative sources that should be used before publication.
6. Give a final publishability judgment.

## Output format

1. `# 事实与技术准确性检查报告`
2. `## 1. 总体风险评级`
3. `## 2. 需要核查的事实点`
4. `## 3. 技术概念准确性`
5. `## 4. 可能过度简化或误导的表述`
6. `## 5. 建议修改表达`
7. `## 6. 需要补充的权威信源`
8. `## 7. 可发布判断`

## References

Read `references/shared-brand-context.md` whenever brand positioning, tags, column system, color system, GEO strategy, or voice rules are needed.
