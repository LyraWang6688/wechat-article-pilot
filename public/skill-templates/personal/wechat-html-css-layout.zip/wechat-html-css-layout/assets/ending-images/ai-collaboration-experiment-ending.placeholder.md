# ai-collaboration-experiment-ending placeholder

Replace with the real fixed ending image URL after upload.
