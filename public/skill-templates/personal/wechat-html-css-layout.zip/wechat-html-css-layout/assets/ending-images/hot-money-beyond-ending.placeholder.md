# hot-money-beyond-ending placeholder

Replace with the real fixed ending image URL after upload.
