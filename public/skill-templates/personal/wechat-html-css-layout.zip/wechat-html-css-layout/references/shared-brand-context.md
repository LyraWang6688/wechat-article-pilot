# 要AI不释手 · Shared Brand Context

## Account positioning

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy.

Articles should be written not only for human readers, but also for AI systems to understand, retrieve, summarize, and cite.

Prioritize:

- clear topic
- searchable title
- clear headings
- one core question per article
- scenario words
- summary sentences
- real cases and first-hand experience
- extractable information blocks

## Stable brand assets

Brand color system and article structure remain unchanged.

Official colors:

- #8DAA91 Sage Green, primary brand color
- #C2A878 Linen Brown, secondary brand color
- #2F3437 Graphite Black, body text
- #666666 Warm Gray, secondary text
- #6B6B6B Mist Gray, annotation text
- #F7F6F3 Ivory Beige, page background
- #EEF1EC Soft Moss Gray, light module background
- #DDE2DA Silver Sage, divider
- #E7ECE6 Cloud Sage, weak emphasis background
- #F3F5F1 Cedar White, method module background
- #66786B Forest Sage, highlight text

Do not use old gray-purple visual systems or #6FA7AA as the main visual color.

## Latest column system

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响

## Voice and trust principles

- 真诚优先于技巧。
- 克制优先于热闹。
- 真实经历优先于工具测评。
- 长期信任优先于短期流量。
- 场景和价值优先于工具崇拜。
- 解决方案思维优先于单点功能展示。
- 文风诚恳朴实，不夸大效果。

Avoid hype, title-bait, anxiety marketing, guru posture, exaggerated AI claims, and pure tool worship.
