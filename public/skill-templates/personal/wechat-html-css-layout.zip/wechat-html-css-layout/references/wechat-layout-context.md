# WeChat HTML Fragment Layout Context

## Layout goal

Generate WeChat Official Account article body HTML fragments that can be copied into WeChat Official Account editors or tools such as 壹伴, and can also be used as the `content` body fragment in WeChat draft/article API workflows.

The style must match the brand identity of 要AI不释手: clean, restrained, low-saturation, trustworthy, and suitable for long-form reading.

## Compatibility rules

- Output HTML fragments only, not full standalone HTML documents.
- Do not output `<!DOCTYPE html>`, `<html>`, `<head>`, `<body>`, `<style>`, or `<script>` in official publishing fragments.
- Use inline CSS only.
- Do not rely on external CSS, JavaScript, web fonts, interactive behavior, or custom classes.
- Do not use external web fonts, embed font files, or rely on `@font-face`.
- Prefer stable `section + p + span + img` structures.
- Avoid deeply nested complex HTML.
- Prefer card-style comparison blocks over `<table>` when possible.
- Every card module must include background color, padding, border or border-left, and border-radius.
- Use mobile-first readability.
- If the user asks for preview, produce preview-only HTML separately and clearly label it.
- Never write preview HTML into Supabase `content_html`; only write the official WeChat HTML fragment.

## Fixed color tokens

- Page background: #F7F6F3
- Body text: #2F3437
- Primary brand: #8DAA91
- Highlight text: #66786B
- Light card background: #EEF1EC
- Core idea background: #E7ECE6
- Method background: #F3F5F1
- Divider: #DDE2DA
- Annotation: #6B6B6B

## Typography

The visual target font is 思源黑体 / Source Han Sans SC.

Because WeChat Official Account articles may not reliably load custom or external fonts, use a compatible system font stack that approximates 思源黑体:

```css
font-family:'Source Han Sans SC','Noto Sans CJK SC',-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',Arial,sans-serif;
```

Do not use external web fonts.

Do not embed font files.

Do not rely on `@font-face`.

Typography should feel clean, restrained, readable, and close to the visual tone of 思源黑体.

- Body font size: 15px to 15.5px.
- Line height: about 1.85 to 1.95.
- Letter spacing: 0.6px to 2px depending on template section.
- Body paragraphs may use text-indent: 2em when following the provided template, but component modules should not indent unless necessary.

## Spacing

Follow the one page visual template spacing logic.

Use module-level horizontal margins rather than relying only on the outer container.

Recommended spacing:

- Outer container: `padding:1px 0;background:#F7F6F3;`
- Title card: `margin:24px 8px;`
- Content summary card: `margin:24px 8px;`
- Body paragraph: `margin:16px 8px;`
- Numbered heading: `margin:32px 8px 16px;`
- Core idea / quote card: `margin:24px 8px;padding:18px 18px;`
- Method / checklist card: `margin:24px 8px;padding:18px;`
- Regular information card: `margin:24px 8px;padding:18px;`
- Image module: `margin:24px 8px;`
- Fixed ending image module: `margin:32px 8px 0;`

Avoid using `margin:16px 0` for body paragraphs unless the paragraph is inside a card module.

## Reading info module

Do not add a fixed reading info module unless the user explicitly asks for it.

Do not default-generate:

- reading time
- article column
- keywords
- suitable readers
- reading info card

If the user only asks for article layout, do not infer reading time, target readers, keywords, column metadata, or other reading info.

## Required modules

Use modules as needed:

1. outer container
2. content summary
3. body paragraph
4. core idea / quote module
5. numbered section heading
6. method/checklist module
7. regular information card
8. card-style comparison module
9. image module
10. fixed column ending image module

Only add reading info when the user explicitly asks for it.

## Image URL rules

- Do not use local file paths in the final HTML.
- If a final WeChat image URL is unavailable, use placeholders such as `{{IMAGE_01_URL}}`, `{{COVER_IMAGE_URL}}`, or the column-specific ending image placeholders.
- Before the HTML block, list all image placeholders and describe what image should replace each placeholder.
- For API workflows, images should be uploaded first and the returned/usable image URLs should replace placeholders before draft creation.

## Ending image rule

Every article should end with the fixed image for its column. Do not generate additional fixed text ending unless explicitly requested.

Use this HTML pattern and replace image URL when available:

```html
<section style="margin:32px 8px 0;text-align:center;">
  <img src="COLUMN_ENDING_IMAGE_URL_PLACEHOLDER" style="display:block;width:100%;height:auto;border-radius:12px;" />
</section>
```

If the real URL is unavailable, output the relevant column placeholder and list which column image is needed before the HTML.
