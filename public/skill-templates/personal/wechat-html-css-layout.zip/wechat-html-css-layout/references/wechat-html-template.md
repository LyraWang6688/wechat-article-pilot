# WeChat HTML Fragment Template

Use these patterns to build WeChat Official Account article body HTML fragments. Do not output full standalone HTML pages.

## Outer container

```html
<section style="margin:0 auto;padding:1px 0;background:#F7F6F3;color:#2F3437;font-family:'Source Han Sans SC','Noto Sans CJK SC',-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',Arial,sans-serif;line-height:1.9;letter-spacing:0.8px;">
  <!-- article modules here -->
</section>
```

## Title card

```html
<section style="margin:24px 8px;padding:22px 18px;background:#EEF1EC;border-radius:14px;border:1px solid #DDE2DA;">
  <p style="margin:0 0 8px;color:#8DAA91;font-size:14px;font-weight:700;letter-spacing:1.2px;">栏目 / 子栏目</p>
  <h1 style="margin:0;color:#2F3437;font-size:22px;line-height:1.45;font-weight:700;letter-spacing:0.8px;">文章标题</h1>
</section>
```

## Content summary card

```html
<section style="margin:24px 8px;padding:18px;background:#EEF1EC;border-radius:12px;border:1px solid #DDE2DA;">
  <p style="margin:0 0 8px;color:#66786B;font-size:15px;font-weight:700;">内容概要</p>
  <p style="margin:0;color:#2F3437;font-size:15px;line-height:1.85;">这里放文章摘要或导读内容。</p>
</section>
```

## Body paragraph

```html
<p style="margin:16px 8px;font-size:15.5px;line-height:1.95;color:#2F3437;text-align:justify;">
  正文内容。
</p>
```

## Numbered heading

```html
<section style="margin:32px 8px 16px;">
  <p style="margin:0 0 6px;color:#8DAA91;font-size:18px;font-weight:700;letter-spacing:1px;">01</p>
  <h2 style="margin:0;color:#2F3437;font-size:20px;line-height:1.5;font-weight:700;">小标题</h2>
</section>
```

## Core idea card

```html
<section style="margin:24px 8px;padding:18px 18px;background:#E7ECE6;border-left:4px solid #8DAA91;border-radius:12px;">
  <p style="margin:0;color:#2F3437;font-size:16px;line-height:1.8;font-weight:600;">核心观点。</p>
</section>
```

## Method card

```html
<section style="margin:24px 8px;padding:18px;background:#F3F5F1;border:1px solid #DDE2DA;border-radius:12px;">
  <p style="margin:0 0 8px;color:#66786B;font-size:15px;font-weight:700;">方法 / 清单</p>
  <p style="margin:0;color:#2F3437;font-size:15px;line-height:1.85;">具体内容。</p>
</section>
```

## Regular information card

```html
<section style="margin:24px 8px;padding:18px;background:#EEF1EC;border:1px solid #DDE2DA;border-radius:12px;">
  <p style="margin:0;color:#2F3437;font-size:15px;line-height:1.85;">信息卡片内容。</p>
</section>
```

## Image module

```html
<section style="margin:24px 8px;text-align:center;">
  <img src="{{IMAGE_01_URL}}" style="display:block;width:100%;height:auto;border-radius:12px;" />
</section>
```

## Fixed ending image module

```html
<section style="margin:32px 8px 0;text-align:center;">
  <img src="COLUMN_ENDING_IMAGE_URL_PLACEHOLDER" style="display:block;width:100%;height:auto;border-radius:12px;" />
</section>
```
