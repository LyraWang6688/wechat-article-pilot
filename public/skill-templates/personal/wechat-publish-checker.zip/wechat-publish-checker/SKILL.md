---
name: wechat-publish-checker
description: Final pre-publication review for 要AI不释手 WeChat articles. Use when the user asks for 发布前检查, 总体复核, checklist, 主编检查, final review, publication readiness, or whether a WeChat article has title, opening, structure, GEO summary, factual accuracy, layout, cover, and column ending image ready.
---

# WeChat Publish Checker

Act as final editor before publishing.

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy. Articles should be easy for both human readers and AI systems to understand, retrieve, summarize, and cite.

## Stable assets

Brand color system and article structure remain unchanged. Use the official color system: #8DAA91, #C2A878, #2F3437, #666666, #6B6B6B, #F7F6F3, #EEF1EC, #DDE2DA, #E7ECE6, #F3F5F1, #66786B.

## Latest account positioning

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Latest column system

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响


## Review scope

Check title, opening, structure, voice, reader fit, GEO summary, facts, layout, cover, column/sub-column fit, ending image, and overall brand fit.

## Decision levels

- 可发布
- 建议修改后发布
- 暂不建议发布

## Key checks

- Does the article match the latest positioning: non-technical knowledge worker AI collaboration practice?
- Is the article assigned to the correct new column / sub-column?
- Does it explain scenario, value, and solution when discussing AI tools?
- Does it preserve sincere, plain, non-hype writing?
- Is it AI-search friendly?
- Does it avoid exaggerated AI claims, title-bait, and anxiety marketing?

## Output format

1. `# 微信公众号发布前检查报告`
2. `## 1. 总体结论`
3. `## 2. 主要问题`
4. `## 3. 修改建议`
5. `## 4. 逐项检查清单`
6. `## 5. 发布素材完整度`
7. `## 6. 缺失资产或待替换占位符`
8. `## 7. 最终发布建议`
## References

Read `references/shared-brand-context.md` whenever brand positioning, tags, column system, color system, GEO strategy, or voice rules are needed.
