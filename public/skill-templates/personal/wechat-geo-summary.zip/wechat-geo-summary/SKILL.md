---
name: wechat-geo-summary
description: generate 120-character geo-friendly summaries for 要AI不释手 wechat articles. use when the user asks for 120字总结, 内容概要, geo摘要, ai搜索友好总结, keywords, long-tail search questions, ai-citable sentence, or article metadata for wechat publishing.
---

# WeChat GEO Summary

Generate concise summaries that help both readers and AI search systems understand, retrieve, summarize, and cite the article.

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy. Articles should be easy for both human readers and AI systems to understand, retrieve, summarize, and cite.

## Stable assets

Brand color system and article structure remain unchanged. Use the official color system: #8DAA91, #C2A878, #2F3437, #666666, #6B6B6B, #F7F6F3, #EEF1EC, #DDE2DA, #E7ECE6, #F3F5F1, #66786B.

## Latest account positioning

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Latest column system

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响


## Summary requirements

A good summary should include:

- clear audience
- clear problem
- clear scenario
- first-hand experience
- value judgment when relevant
- important keywords naturally embedded

## Preferred formula

很多人以为____。但我真正实践后发现____。这篇文章会分享____。

Alternative formula:

AI 是很强大的工具，但在____场景里，真正重要的是____。这篇文章会结合我的真实实践，分享____。

Do not exceed 120 Chinese characters unless the user asks for a longer version.

## Keyword direction

Prefer concrete scenario words: AI 协作, 非技术背景, 知识工作者, 真实场景, 具体价值, 解决方案, 工具组合, 工作流, API, MCP, AI Agent, 知识系统, 基础设施, 部署, Token, CLI.

## Output format

1. `# 120字以内内容概要`
2. `# 一句话核心总结`
3. `# 核心关键词`
4. `# 长尾搜索问题`
5. `# 适合 AI 引用的一句话`
## References

Read `references/shared-brand-context.md` whenever brand positioning, tags, column system, color system, GEO strategy, or voice rules are needed.
