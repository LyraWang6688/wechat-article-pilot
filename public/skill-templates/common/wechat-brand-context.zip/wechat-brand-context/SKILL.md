---
name: wechat-brand-context
description: WeChat official account brand context for 要AI不释手. Use when the user asks to inspect, update, summarize, or apply the account positioning, tags, column system, brand colors, writing principles, visual rules, GEO goals, content boundaries, or long-term content strategy for the WeChat official account.
---

# WeChat Brand Context

Use this skill as the platform-specific brand master source for the WeChat Official Account “要AI不释手”.

## References

Use `references/full-brand-context.md` as the authoritative detailed brand context when the user needs platform guidance, column fit, visual rules, writing rules, GEO standards, or update comparison.

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy. Articles should be easy for both human readers and AI systems to understand, retrieve, summarize, and cite.

## Stable assets

Brand color system and article structure remain unchanged. Use the official color system: #8DAA91, #C2A878, #2F3437, #666666, #6B6B6B, #F7F6F3, #EEF1EC, #DDE2DA, #E7ECE6, #F3F5F1, #66786B.

## Latest account positioning

「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。

Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Latest column system

- AI 协作实验
  - 造物笔记：从 0 到 1，把想法做成小产品 / 小系统
  - 从卡点到解法：问题拆解、技术卡点、方案选择
  - 工具炼金术：AI 工具组合、提效实践、工作流整合
  - 概念补给站：Skill、CLI、部署、API、Token 等基础概念讲解
- 边走边想：个人成长、情绪复盘、职业思考、长期主义
- 书籍推荐：阅读输入、认知补给
- 热钱之外：投资理性、市场观察、普通投资者判断力训练
- AI 简报：AI 资讯整理、趋势观察、机会识别、劳动力市场影响


## Core behavior

- Preserve the latest positioning: non-technical knowledge worker AI collaboration practice.
- Treat AI as a powerful tool, not the answer itself.
- Emphasize real scenarios, concrete value, and implementable solutions.
- Preserve sincerity, plain expression, restraint, consistency, real practice, and long-term trust.
- Keep GEO / AI-Friendly Writing as the long-term unchanged content strategy.
- Do not turn the brand into hype, title-bait, generic AI news aggregation, or pure AI tool worship.

## Main use cases

1. Explain the account positioning and column strategy.
2. Extract brand rules for another WeChat content Skill.
3. Update the WeChat brand context after the user provides new materials.
4. Check whether a proposed topic fits the WeChat account.
5. Clarify visual, writing, and GEO standards.
6. Distinguish what changed and what stayed stable after a positioning or column update.

## Output standard

When asked for brand guidance, respond with concise structured sections: positioning, audience, column fit, writing style, visual rules, GEO strategy, risks, and suggested next step.
