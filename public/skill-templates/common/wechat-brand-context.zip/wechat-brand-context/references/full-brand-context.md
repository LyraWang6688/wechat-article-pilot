# WeChat Official Account Brand Context

## Account identity

- Account name: 要AI不释手
- Latest positioning: 「要AI不释手」记录一个非技术背景知识工作者，如何在真实项目中与 AI 协作，把想法、工具、知识和流程，逐步变成可用的产品、系统和解决方案。
- Core IP: 长期 AI 协作实践 IP；普通人进入 AI 产品时代的真实陪跑者；成长型实践者。
- Core sentence: AI 是很强大的工具，但工具本身不是答案。真正重要的是：找到真实场景、识别具体价值，并设计可落地的解决方案。

## Stable strategy

GEO / AI-Friendly Writing remains the long-term content strategy. Articles should be easy for both human readers and AI systems to understand, retrieve, summarize, and cite.

Stable priorities:

1. Be discoverable and citable by AI search / GEO.
2. Build a long-term trustworthy IP.
3. Attract people who genuinely need AI product implementation and AI collaboration guidance.
4. Accumulate real practice experience.
5. Grow through long-term iteration rather than short-term traffic tricks.

## Stable assets

Brand color system and article structure remain unchanged. Use the official color system and recommended WeChat article structure below. Do not revert to old gray-purple or high-saturation visual systems.

## Latest tags

- #非技术背景
- #知识工作者
- #AI协作实践
- #认真记录
- #持续探索
- #场景驱动
- #价值导向
- #解决方案思维
- #不神化AI也不制造焦虑
- #文风诚恳朴实，不夸大效果
- #长期主义
- #值得信任和同行
- #成长型实践者

## Audience

Potential readers are people who already sense that AI will change knowledge work, product development, and business processes, but do not yet know how to truly move from idea to usable product, system, workflow, or solution.

Serve especially:

- non-technical AI product learners
- knowledge workers trying to collaborate with AI in real projects
- product / operations / business people trying AI Coding and AI workflow tools
- people learning API, database, workflow, deployment, agent, CLI, token, MCP, and automation concepts through practice
- readers who value truthful practice over hype
- ordinary investors and professionals who want rational observation rather than anxiety-driven information consumption

## Voice and trust principles

Always preserve these principles:

1. 真诚优先于技巧。
2. 克制优先于热闹。
3. 统一优先于花样。
4. 真实经历优先于工具测评。
5. 长期信任优先于短期流量。
6. 场景驱动优先于工具崇拜。
7. 价值导向优先于炫技表达。
8. 解决方案思维优先于单点技巧堆砌。

Do not write in a sensational, fear-based, guru-like, marketing-hype, title-bait, generic AI news aggregation, or pure AI tool worship tone.

## Latest column system

### AI 协作实验

Purpose: record how a non-technical knowledge worker collaborates with AI in real projects and turns ideas, tools, knowledge, and workflows into usable products, systems, and solutions.

Subcolumns:

#### 造物笔记

Focus: from 0 to 1, turning an idea into a small product / small system.

Typical content:

- AI Coding practice
- product implementation
- requirements decomposition
- frontend / backend / API / database / deployment learning through real projects
- prototype to usable product process
- real obstacles and iteration records

#### 从卡点到解法

Focus: problem decomposition, technical blockers, decision logic, and solution selection.

Typical content:

- where the project got stuck
- what was misunderstood
- how the problem was decomposed
- why one solution was chosen over another
- what a non-technical person learned from the blocker

#### 工具炼金术

Focus: AI tool combination, productivity practice, and workflow integration.

Typical content:

- AI tools in combination rather than isolated reviews
- workflow design
- prompt / tool / data / automation collaboration
- practical productivity improvement in real work scenes

#### 概念补给站

Focus: explain basic technical and AI-product concepts through real usage scenarios.

Typical concepts:

- Skill
- CLI
- deployment
- API
- token
- database
- MCP
- AI Agent
- workflow
- frontend / backend basics

### 边走边想

Purpose: record growth, reflection, emotional self-correction, career thinking, and long-termism.

Column ending image: `assets/wechat/ending-images/walking-thinking-ending.png` placeholder until supplied.

### 书籍推荐

Purpose: share books that truly changed how the creator understands problems, technology, self, or the world.

Column ending image: `assets/wechat/ending-images/book-recommendation-ending.png` placeholder until supplied.

### 热钱之外

Purpose: rational investing observation for ordinary investors. Do not recommend stocks, predict the market, or manufacture wealth anxiety.

When working with this column, use stricter fact checking, source requirements, and financial expression boundaries.

Column ending image: `assets/wechat/ending-images/hot-money-beyond-ending.png` placeholder until supplied.

### AI 简报

Purpose: AI information curation, trend observation, opportunity identification, and labor market impact tracking.

Typical content:

- AI business updates
- AI regulation and policy
- AI investment and capital market signals
- major AI product and model updates
- Agent technology and ecosystem changes
- AI impact on labor markets, including employment, job structure, skill demand, wages, enterprise hiring, white-collar work, developer work, and Agent automation

Column ending image: `assets/wechat/ending-images/ai-briefing-ending.png` placeholder until supplied.

## Color system

- Primary brand color: #8DAA91, Sage Green, used for titles, emphasis, module titles, brand recognition.
- Secondary brand color: #C2A878, Linen Brown, used for editor notes, emotional warmth, soft backgrounds.
- Body text: #2F3437, Graphite Black.
- Secondary text: #666666, Warm Gray.
- Annotation text: #6B6B6B, Mist Gray.
- Page background: #F7F6F3, Ivory Beige.
- Light module background: #EEF1EC, Soft Moss Gray.
- Divider: #DDE2DA, Silver Sage.
- Weak emphasis background: #E7ECE6, Cloud Sage.
- Method module background: #F3F5F1, Cedar White.
- Highlight text: #66786B, Forest Sage.

Avoid high-saturation blue-purple, neon colors, excessive gradients, and old gray-purple visual systems.

## Writing structure rules

- Start directly with the problem.
- One article should focus on one core question.
- Use clear headings.
- Use short paragraphs, usually 1-3 lines.
- Include real experience, actual obstacles, and practical judgment.
- Use summary sentences that are easy to cite.
- Use scene keywords such as AI 产品, AI Coding, AI 协作, 非技术背景, 知识工作者, 产品落地, 提示词, React, API, 工作流, MCP, AI Agent, 解决方案, 场景驱动, 价值导向.
- Do not write generic AI news aggregation.
- Do not exaggerate AI capability or imply tools alone solve the real problem.

## WeChat article recommended structure

1. Reading info: full length and estimated reading time.
2. Content summary module with 3-5 bullets.
3. Opening hook: what I recently did, what real problem I met, why it matters, what this article answers.
4. 4-6 main sections using clear numbered headings.
5. Optional components: quote/core idea, real experience, method module, editor note/my understanding.
6. Summary module before the ending.
7. Fixed column ending image; do not generate extra fixed text ending unless the user asks.

## Cover style

- Minimal, restrained, spacious.
- Technology feeling but not cold.
- Low saturation colors.
- Product UI / computer / workflow / work scene elements are preferred.
- Do not use exaggerated facial expressions.
- Do not use poster-like big-character style.
- Prefer stable column identity.
- Suggested structure: left side strong title + small label + one-line subtitle; right side product image/UI/work scene/computer.

## GEO summary rule

A 120-character summary should include:

1. clear audience
2. clear problem
3. clear scenario
4. first-hand experience

Useful formula:

很多人以为____。但我真正实践后发现____。这篇文章会分享____。

## Publication checklist baseline

Check whether:

- title is clear
- opening is direct
- the article states one clear theme
- real experience is present
- concrete examples are present
- logic is smooth
- shareable insight exists
- account positioning is respected
- AI search/GEO friendliness is present
- title-bait is avoided
- AI capability is not exaggerated
- paragraphs are not too long
- fixed column ending image is included
- fact-checking has been performed when needed

## What changed in this update

- Positioning changed from “AI Coding 产品真正落地” to broader “非技术背景知识工作者的 AI 协作实践”。
- Core logic changed from tool/product-output centered to “真实场景 + 具体价值 + 可落地解决方案” centered.
- Column system changed: the original AI 产品落地方向 is now integrated into “AI 协作实验”, with four subcolumns: 造物笔记、从卡点到解法、工具炼金术、概念补给站.
- AI 简报 explicitly includes labor market impact.
- GEO / AI-Friendly Writing, brand colors, article structure, sincerity, restraint, real practice, and long-term trust remain stable.
